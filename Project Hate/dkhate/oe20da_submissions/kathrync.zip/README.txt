Team name: JAK, Johannes Bernhard, Ataur Rahman, Kathryn Chapman
University: Universität des Saarlandes

Model: xlm-roberta (multi-lingual) language model fine-tuned on all train and test tweets from task a plus a classifier layer fine-tuned on OffensEval 2020's task a training data for all languages + OffensEval 2019's task a training data (english-only)

Note: this is the same, single multi-lingual model used with all other languages in subtask a