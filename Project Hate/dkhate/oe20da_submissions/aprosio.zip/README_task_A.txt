### Team

Camilla Casula, Alessio Palmero Aprosio, Stefano Menini
Fondazione Bruno Kessler, Trento, Italy


### Description of the task

For the participation to the task, we train a ML model using three datasets:
  (a) The collection taken from [1, 2, 3, 4, 5]
  (b) OLID [6]
  (c) The training set from Offenseval 2020 task

The English datasets (a) and (b) have been translated to Greek, Arabic, Turkish and Danish using Google Translate.
Similarly, the datasets (c) have been translated to English.

Then, vectors from the English version of Bert are extracted for the English sentences, while vectors from the multi-language version are extracted for the sentences in other languages. Vectors are then added.
Source code of the approach will be available after the task.


### References

[1] Waseem, Zeerak  and  Hovy, Dirk. Hateful Symbols or Hateful People? Predictive Features for Hate Speech Detection on Twitter. Proceedings of the NAACL Student Research Workshop. 2016

[2] Waseem, Zeerak. Are You a Racist or Am I Seeing Things? Annotator Influence on Hate Speech Detection on Twitter. Proceedings of the First Workshop on NLP and Computational Social Science. 2016

[3] Founta, Antigoni-Maria and Djouvas, Constantinos and Chatzakou, Despoina and Leontiadis, Ilias and Blackburn, Jeremy and Stringhini, Gianluca and Vakali, Athena and Sirivianos, Michael and Kourtellis, Nicolas. Large Scale Crowdsourcing and Characterization of Twitter Abusive Behavior. 11th International Conference on Web and Social Media, ICWSM. 2018
    
[4] Davidson, Thomas and Warmsley, Dana and Macy, Michael and Weber, Ingmar. Automated Hate Speech Detection and the Problem of Offensive Language. Proceedings of the 11th International AAAI Conference on Web and Social Media.  ICWSM '17. 2017

[5] Golbeck, Jennifer and Ashktorab, Zahra and Banjo, Rashad O and Berlinger, Alexandra and Bhagwan, Siddharth and Buntain, Cody and Cheakalos, Paul and Geller, Alicia A and Gnanasekaran, Rajesh Kumar and Gunasekaran, Raja Rajan and others. A large labeled corpus for online harassment research. Proceedings of the 2017 ACM on web science conference. 2017

[6] Zampieri, Marcos and Malmasi, Shervin and Nakov, Preslav and Rosenthal, Sara and Farra, Noura and Kumar, Ritesh. Predicting the Type and Target of Offensive Posts in Social Media. Proceedings of NAACL. 2019