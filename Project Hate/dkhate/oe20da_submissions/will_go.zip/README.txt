TFIDF method with threshold 
add:bert blend